#/bin/bash


###### aliases ######
alias rfs="grep -i href"
alias ims='grep -iE "jpg|jpeg"'
alias chs="wc -m"


###### ENV's ######
export CROOT=~/class
export EXAM1=~/class/e01
