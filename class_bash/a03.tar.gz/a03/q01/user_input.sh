#!/bin/bash
#
#	Sample script to demonstrate getting user input from the terminal
#
#	Sample script with no editting of the input and no default
#
echo -n "Please enter your last name: "
read name
echo "Hello. Is this your last name: $name?"

