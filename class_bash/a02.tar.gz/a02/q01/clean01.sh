#!/bin/bash
#
#	This routine is intended to cleanup everything the workXX.sh file does.
#
chmod -x solution.pl decode.sh
