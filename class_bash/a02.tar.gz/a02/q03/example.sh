#!/bin/bash
echo "Hello"
echo "Bye"
echo "This is a test"
