#!/bin/bash

file=$1


# while read line
#    do
#    echo $line
# done < $file



while :
do

    echo -n 'Please enter the search term: '
    read term

    if [ ! -z $term ]; then

        grep -iw $term $file | wc -l

    else
	echo "Search term not provided. Exiting..."
	exit
    fi

    echo ""
done
